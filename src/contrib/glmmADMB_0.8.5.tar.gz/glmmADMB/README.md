This is the new development space for the `glmmADMB` package, generalized linear mixed models based on [AD Model Builder](http://admb-project.org). For now, see the [web page based on r-forge](http://glmmadmb.r-forge.r-project.org/) for information.

## Installation

1. Install `devtools` if necessary: `install_packages("devtools")`
2. Install `R2admb` (this step may be unnecessary?): `install_packages("R2admb")`
3. `devtools::install_github("bbolker/glmmadmb")`


